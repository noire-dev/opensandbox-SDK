// OpenSandbox by noire.dev — GPLv2

#ifndef __UI_LOCAL_H__
#define __UI_LOCAL_H__

#define MAX_DESKTOP_ITEMS 200

#define MTYPE_NULL 0
#define MTYPE_BUTTON 1
#define MTYPE_CHECKBOX 2
#define MTYPE_SLIDER 3
#define MTYPE_ACTION 4
#define MTYPE_SPIN 5
#define MTYPE_FIELD 6
#define MTYPE_LIST 7

#define UI_STRINGLENGTH 128
#define UI_ACTIONLENGTH 256
#define UI_BINDLENGTH 256
#define UI_OPTIONSLENGTH 64
#define UI_OPTIONSCOUNT 32
#define UI_FIELDLENGTH 256

#define EMODE_NONE 0
#define EMODE_INT 1
#define EMODE_FLOAT 2

#define EMODE_NUMBER 1
#define EMODE_STRING 2

typedef struct {
	int type;
	int id;
	float x, y, w, h;
	char text[UI_STRINGLENGTH];
	int style;
	float size;
	int colortext, colorbg;
	int corner;
	int margin;
	char action[UI_ACTIONLENGTH];
	
	float value;
	
	float min, max;
	int mode;
	
	char bind[UI_BINDLENGTH];
	
	char options[UI_OPTIONSCOUNT][UI_OPTIONSLENGTH];
	int optionsCount;
	
	char field[UI_FIELDLENGTH];
	int fieldPosition;
	
	int list;
	int drawCount;
} menuelement_s;

#define APP_NAMEID_LENGTH 32
#define APP_NAME_LENGTH 128
#define APP_ICON_LENGTH 64
typedef struct {
    qboolean created;
    char nameid[APP_NAMEID_LENGTH];
    char name[APP_NAME_LENGTH];
    char icon[APP_ICON_LENGTH];
} app_s;

#define WINDOW_NAMEID_LENGTH 32
#define WINDOW_NAME_LENGTH 128
#define WINDOW_MAX_ITEMS 64
typedef struct {
    qboolean created;
    qboolean minimized;
    char nameid[WINDOW_NAMEID_LENGTH];
    char name[WINDOW_NAME_LENGTH];
    menuelement_s i[WINDOW_MAX_ITEMS];
    float x, y, h, w;
    char list256[1024*256];
    char list64[1024*64];
    char list16[1024*16];
    char list4[1024*4];
} window_s;

#define UI_MAX_WINDOWS 64
#define UI_MAXLISTS 8
#define UI_LISTLENGTH 1048576
#define UI_LISTFOLDERLENGTH 256
#define UI_LISTEXTENSIONLENGTH 16
typedef struct {
	int cursorx;
	int cursory;
	qboolean onmap;
	
	window_s windows[UI_MAX_WINDOWS];
	
	int currentItem;
	menuelement_s items[MAX_DESKTOP_ITEMS];
	int waitingKey;
	
	char list[UI_MAXLISTS][UI_LISTLENGTH];
	int listCount[UI_MAXLISTS];
	char drawFolder[UI_MAXLISTS][UI_LISTFOLDERLENGTH];
	char drawExtension[UI_MAXLISTS][UI_LISTEXTENSIONLENGTH];
} uiStatic_t;

// ui_atoms.c
void UI_SetActiveMenu(uiMenuCommand_t menu);
void UI_KeyEvent(int key, int down, int isChar);
void UI_MouseEvent(int dx, int dy);
qboolean UI_ConsoleCommand(int realTime);
void UI_Shutdown(void);
void UI_Init(void);

// ui_connect.c
void UI_DrawConnectScreen(qboolean overlay);

// ui_main.c
void UI_CreateCvars(void);

// ui_menu.c
void MenuDraw(void);
void UI_Menu(void);
void UI_HotReloadJS(void);

// ui_qmenu.c
qboolean Menu_CursorOnItem(int id);
qboolean Menu_CursorInRect(int x, int y, int w, int h);
void Menu_ElementsDraw(void);
void Menu_DefaultKey(int key, int isDown, int isChar);
int UI_CButton(int id, float x, float y, float w, float h, char *text, int style, float size, int colortext, int colorbg, int corner, int margin, char *action);
int UI_CCheckbox(int id, float x, float y, float w, float h, char *text, int style, float size, int colortext, int colorbg, int corner, int margin, char *action);
int UI_CSlider(int id, float x, float y, float w, float h, char *text, int style, float size, int colortext, int colorbg, int corner, int margin, char *action, float min, float max, int mode);
int UI_CAction(int id, float x, float y, float w, float h, char *text, int style, float size, int colortext, int colorbg, int corner, int margin, char *action);
int UI_CSpin(int id, float x, float y, float w, float h, char *text, int style, float size, int colortext, int colorbg, int corner, int margin, char *action, int mode);
int UI_CField(int id, float x, float y, float w, float h, char *text, int style, float size, int colortext, int colorbg, int corner, int margin, char *action);
int UI_CList(int id, float x, float y, float w, float h, char *text, int style, float size, int colortext, int colorbg, int corner, int margin, char *action, int list, int drawCount);

void UI_FillListFiles(int list, const char *folder, const char *extension, const char *drawFolder, const char *drawExtension);

extern uiStatic_t uis;
extern const char *gametype_items[GT_MAX_GAME_TYPE + 1];

#define CON_MAXLINES 16384
#define CON_MAXLINE 256

typedef struct console_s {
	char lines[CON_MAXLINES][CON_MAXLINE];
	int linescount;
} console_t;

extern console_t console;
extern int consoleLines;

// syscalls
void trap_Key_SetBinding(int keynum, const char *binding);
void trap_Key_ClearStates(void);
void trap_Key_SetCatcher(int catcher);
void trap_GetClipboardData(char *buf, int bufsize);
void trap_GetClientState(uiClientState_t *state);
int trap_GetConfigString(int index, char *buff, int buffsize);
int trap_LAN_GetPingQueueCount(void);
void trap_LAN_ClearPing(int n);
void trap_LAN_GetPing(int n, char *buf, int buflen, int *pingtime);
void trap_LAN_GetPingInfo(int n, char *buf, int buflen);
int trap_MemoryRemaining(void);
int trap_LAN_GetServerCount(int source);
void trap_LAN_GetServerAddressString(int source, int n, char *buf, int buflen);
void trap_LAN_GetServerAddressString(int source, int n, char *buf, int buflen);
void consoleSync(console_t *vmconsole, int currentLines);
#endif
