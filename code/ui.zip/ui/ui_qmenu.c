// Copyright (C) 1999-2005 ID Software, Inc.
// OpenSandbox by noire.dev — GPLv2

#include "../shared/javascript.h"

void adjustToWindow(int windowID, float *x, float *y, float *w, float *h) {
	*x = *x;
	*y *= cgui.scale;
	*w *= cgui.scale;
	*h *= cgui.scale;
}

qboolean Menu_CursorOnItem(int id) {
	if(uis.cursorx < uis.items[id].x || uis.cursory < uis.items[id].y || uis.cursorx > uis.items[id].x + uis.items[id].w || uis.cursory > uis.items[id].y + uis.items[id].h) return qfalse;
	return qtrue;
}

qboolean Menu_CursorInRect(int x, int y, int w, int h) {
	if(uis.cursorx < x || uis.cursory < y || uis.cursorx > x + w || uis.cursory > y + h) return qfalse;
	return qtrue;
}

void getItemFromList(int list, int index, char *buffer, int bufferSize) {
    char *file;
    int i;
    
    if (list < 0 || list >= UI_MAXLISTS || index < 0 || index >= uis.listCount[list]) return;
    file = uis.list[list];
    for (i = 0; i < index; i++) file += strlen(file) + 1;
    StringCopy(buffer, file, bufferSize - 1);
}

#define CB_NONE 0
#define CB_COMMAND 1
#define CB_VARIABLE 2
#define CB_FUNC 3

static void DrawTip(const char *text) {
	drawRoundedRect((uis.cursorx - 5) + 17, uis.cursory - 21, stringWidth(text, 1.00, 0)+10, BASEFONT_HEIGHT + 4, 0, cgui.colors[JSCOLOR_TIPSHADOW]);
	drawRoundedRect((uis.cursorx - 5) + 18, uis.cursory - 20, stringWidth(text, 1.00, 0)+10, BASEFONT_HEIGHT + 4, 0, cgui.colors[JSCOLOR_TIP]);
	drawString(uis.cursorx + 18, uis.cursory - 18, text, 0, cgui.colors[JSCOLOR_TIPTEXT], 1.00);
}

static float SliderValue(float min, float max, float x, float w) {
    float local_x = (float)uis.cursorx - x;
    
    if(local_x < 0.0f) local_x = 0.0f;
    if(local_x > w) local_x = w;
    
    return min + (local_x / w) * (max - min);
}

static void UI_GeneralCallback(menuelement_s *item, int key) {
    int i;
	switch(item->type) {
    case MTYPE_BUTTON:
        if(strlen(item->action)) trap_Cmd(EXEC_INSERT, (item->action));
        break;
    case MTYPE_CHECKBOX:
        if(item->value > 0) item->value = 0;
        else item->value = 1;
        if(strlen(item->action)) cvarSet(item->action, va("%f", item->value));
        break;
	case MTYPE_SLIDER:
        switch(key) {
	    case K_MOUSE1:
	        if(Menu_CursorOnItem(item->id)) { 
	            if(item->mode == EMODE_INT) item->value = (int)(SliderValue(item->min, item->max, item->x+(item->w*0.5), (item->w*0.5)-item->margin));
	            if(item->mode == EMODE_FLOAT) item->value = SliderValue(item->min, item->max, item->x+(item->w*0.5), (item->w*0.5)-item->margin);
	        }
	        break;
	    }
        if(strlen(item->action)) cvarSet(item->action, va("%f", item->value));
        break;
    case MTYPE_ACTION:
        uis.waitingKey = item->id;
        break;
    case MTYPE_SPIN:
        switch(key) {
	    case K_MOUSE1:
	        if(item->value < item->optionsCount-1) item->value += 1;
	        else item->value = 0;
	        break;
	    }
	    if(item->mode == EMODE_NUMBER) cvarSet(item->action, va("%f", item->value));
	    else if(item->mode == EMODE_STRING) cvarSet(item->action, va("%s", item->options[(int)item->value]));
        break;
    case MTYPE_FIELD:
        uis.waitingKey = item->id;
        break;
    case MTYPE_LIST:
        switch(key) {
	    case K_MOUSE1:
    	    for(i = 0; i < uis.listCount[item->list]; i++) {
                if(Menu_CursorInRect(item->x, item->y + (i*(item->h/item->drawCount)), item->w, (item->h/item->drawCount))) item->value = i;
            }
	        break;
	    }
	    getItemFromList(item->list, (int)item->value, item->field, UI_FIELDLENGTH);
	    if(strlen(item->action)) cvarSet(item->action, item->field);
        break;
	}
}

#define UISTYLE_Y e->y+(e->h-(BASEFONT_HEIGHT*e->size))*0.5
#define UISTYLE_HOVER Menu_CursorOnItem(e->id) ? UI_UNDERLINE : 0
#define UISTYLE_BACKGROUND e->x, e->y, e->w, e->h, e->corner, cgui.colors[e->colorbg]
#define UISTYLE_CENTER_TEXT(text) e->x+(e->w*0.5), text_y, text, UI_CENTER|e->style|hoverStyle, cgui.colors[e->colortext], e->size
#define UISTYLE_RIGHT_TEXT(text) (e->x+e->w)-e->margin, text_y, text, UI_RIGHT|e->style|hoverStyle, cgui.colors[e->colortext], e->size
#define UISTYLE_LEFT_TEXT(text) e->x+e->margin, text_y, text, e->style|hoverStyle, cgui.colors[e->colortext], e->size

static void Button_Draw(menuelement_s *e) {
    float text_y = UISTYLE_Y;
    int hoverStyle = UISTYLE_HOVER;
    
    drawRoundedRect(UISTYLE_BACKGROUND);
    if(e->style & UI_CENTER) drawString(UISTYLE_CENTER_TEXT(e->text));
    else if(e->style & UI_RIGHT) drawString(UISTYLE_RIGHT_TEXT(e->text));
    else drawString(UISTYLE_LEFT_TEXT(e->text));
}

static void Checkbox_Draw(menuelement_s *e) {
    float text_y = UISTYLE_Y;
    int hoverStyle = UISTYLE_HOVER;
    int colorbox = e->value ? JSCOLOR_ENABLED : JSCOLOR_DISABLED;
    
    drawRoundedRect(UISTYLE_BACKGROUND);
    drawRoundedRect(((e->x+e->w)-e->h*0.50)-e->margin, (e->y+(e->h*0.5))-e->h*0.25, e->h*0.50, e->h*0.50, e->corner, cgui.colors[colorbox]);
    drawString(UISTYLE_LEFT_TEXT(e->text));
}

static float SliderProgress(float value, float min, float max) {
    float result;
    float clamp;
    
    if(value < min) clamp = min;
    else if(value > max) clamp = max;
    else clamp = value;
    
    result = (clamp - min) / (max - min);
    
    if(result <= 0.0f) return 0.0f;
    if(result >= 1.0f) return 1.0f;
    
    return result;
}

static void Slider_Draw(menuelement_s *e) {
    float text_y = UISTYLE_Y;
    int hoverStyle = UISTYLE_HOVER;
    
	drawRoundedRect(UISTYLE_BACKGROUND);
    drawRoundedRect(e->x+(e->w*0.5), (e->y+(e->h*0.5))-e->h*0.25, (e->w*0.5)-e->margin, e->h*0.50, e->corner, cgui.colors[JSCOLOR_DISABLED]);
    drawRoundedRect(e->x+(e->w*0.5), (e->y+(e->h*0.5))-e->h*0.25, ((e->w*0.5)-e->margin)*SliderProgress(e->value, e->min, e->max), e->h*0.50, e->corner, cgui.colors[JSCOLOR_ENABLED]);
    drawString(UISTYLE_LEFT_TEXT(e->text));
    if(Menu_CursorOnItem(e->id)) DrawTip(va("%f", e->value));
}

static void Action_Draw(menuelement_s *e) {
    float text_y = UISTYLE_Y;
    int hoverStyle = UISTYLE_HOVER;
    char *bind = (uis.waitingKey == e->id) ? ">_" : e->bind;
    
    drawRoundedRect(UISTYLE_BACKGROUND);
    drawString(UISTYLE_LEFT_TEXT(e->text));
    drawString(UISTYLE_RIGHT_TEXT(bind));
}

static void Spin_Draw(menuelement_s *e) {
    float text_y = UISTYLE_Y;
    int hoverStyle = UISTYLE_HOVER;
    
	drawRoundedRect(UISTYLE_BACKGROUND);
    drawString(UISTYLE_LEFT_TEXT(e->text));
    drawString(UISTYLE_RIGHT_TEXT(e->options[(int)e->value]));
}

static void Field_Draw(menuelement_s *e) {
    float text_y = UISTYLE_Y;
    int hoverStyle = UISTYLE_HOVER;
    
    if(uis.waitingKey == e->id) hoverStyle = 0;
    
    drawRoundedRect(UISTYLE_BACKGROUND);
    if(uis.waitingKey == e->id) drawStringField(UISTYLE_LEFT_TEXT(e->field), e->fieldPosition);
	else drawStringField(UISTYLE_LEFT_TEXT(e->text), -1);
	if(Menu_CursorOnItem(e->id) && uis.waitingKey == -1) DrawTip(va("%s", e->field));
}

static void List_Draw(menuelement_s *e) {
    float text_y;
    int listHovered = -1;
    int i;
	char *file;
    
	for(i = 0; i < uis.listCount[e->list]; i++) {
        if(Menu_CursorInRect(e->x, e->y + (i*(e->h/e->drawCount)), e->w, (e->h/e->drawCount))) listHovered = i;
    }
    
	file = uis.list[e->list];
	drawRoundedRect(e->x, e->y, e->w, e->h, e->corner, cgui.colors[e->colorbg]);
	for(i = 0; i < uis.listCount[e->list]; i++) {
	    text_y = (e->y+(i*(e->h/e->drawCount)))+((e->h/e->drawCount)-(BASEFONT_HEIGHT*e->size))*0.5;
        if(i == (int)e->value) drawString(e->x+e->margin, text_y, file, e->style, cgui.colors[JSCOLOR_ENABLED], e->size);
        else if(i == listHovered) drawString(e->x+e->margin, text_y, file, e->style|UI_UNDERLINE, cgui.colors[e->colortext], e->size);
        else drawString(e->x+e->margin, text_y, file, e->style, cgui.colors[e->colortext], e->size);
		file += strlen(file) + 1;
	}
}

void Menu_ElementsDraw(void) {
	int i;

	for(i = 0; i < MAX_DESKTOP_ITEMS; i++) {
	    if(uis.items[i].style & UI_NODRAW) continue;
		switch(uis.items[i].type) {
		    case MTYPE_BUTTON: Button_Draw(&uis.items[i]); break;
		    case MTYPE_CHECKBOX: Checkbox_Draw(&uis.items[i]); break;
		    case MTYPE_SLIDER: Slider_Draw(&uis.items[i]); break;
		    case MTYPE_ACTION: Action_Draw(&uis.items[i]); break;
		    case MTYPE_SPIN: Spin_Draw(&uis.items[i]); break;
		    case MTYPE_FIELD: Field_Draw(&uis.items[i]); break;
		    case MTYPE_LIST: List_Draw(&uis.items[i]); break;
		}
	}
	if(uis.waitingKey >= 0) DrawTip("Press any key, ESC for cancel");
}

static void *Menu_CurrentItem(void) {
	if(uis.currentItem < 0 || uis.currentItem >= MAX_DESKTOP_ITEMS) return 0;
	return &uis.items[uis.currentItem];
}

void Menu_DefaultKey(int key, int isDown, int isChar) {
	menuelement_s *item;
	int i;
	
    if(uis.waitingKey >= 0 && uis.items[uis.waitingKey].type == MTYPE_ACTION) {
	    if(key != K_ESCAPE) {
            for(i = 0; i < MAX_KEYS; i++) {
                if(!strcmp(uis.items[uis.waitingKey].action, cgui.binds[i])) trap_Key_SetBinding(i, "");
            }
            trap_Key_SetBinding(key, uis.items[uis.waitingKey].action);
            for(i = 0; i < MAX_KEYS; i++) trap_Key_GetBindingBuf(i, cgui.binds[i], 256);
            JS_MenuInit();
            uis.waitingKey = -1;
	    }
	    return;
    } else if(uis.waitingKey >= 0 && uis.items[uis.waitingKey].type == MTYPE_FIELD) {
        int len;
        item = &uis.items[uis.waitingKey];
        len = strlen(item->field);
        
        if(key != K_ESCAPE) {
            
        }
        
        if(isChar && key >= 32 && key != 127 && len < UI_FIELDLENGTH-1) {
            char utf8[5] = {0};
            int bytes = 0;
            
            if(key < 0x80) {
                utf8[0] = (char)key;
                bytes = 1;
            } else if(key < 0x800) {
                utf8[0] = 0xC0 | (key >> 6);
                utf8[1] = 0x80 | (key & 0x3F);
                bytes = 2;
            } else if(key < 0x10000) {
                utf8[0] = 0xE0 | (key >> 12);
                utf8[1] = 0x80 | ((key >> 6) & 0x3F);
                utf8[2] = 0x80 | (key & 0x3F);
                bytes = 3;
            } else if(key < 0x110000) {
                utf8[0] = 0xF0 | (key >> 18);
                utf8[1] = 0x80 | ((key >> 12) & 0x3F);
                utf8[2] = 0x80 | ((key >> 6) & 0x3F);
                utf8[3] = 0x80 | (key & 0x3F);
                bytes = 4;
            }
            
            if(item->fieldPosition < 0) item->fieldPosition = len;
            if(item->fieldPosition <= len && len + bytes <= UI_FIELDLENGTH-1) {
                memmove(item->field + item->fieldPosition + bytes, item->field + item->fieldPosition, len - item->fieldPosition + 1);
                memcpy(item->field + item->fieldPosition, utf8, bytes);
                
                item->fieldPosition += bytes;
                item->field[len + bytes] = '\0';
            }
        } else if(!isChar) {
            len = strlen(item->field);
            if(item->fieldPosition < 0) item->fieldPosition = len;
            
            if(key == K_LEFTARROW) {
                if(item->fieldPosition > 0) {
                    item->fieldPosition--;
                    while(item->fieldPosition > 0 && 
                          (item->field[item->fieldPosition] & 0xC0) == 0x80) {
                        item->fieldPosition--;
                    }
                }
            } else if(key == K_RIGHTARROW) {
                if(item->fieldPosition < len) {
                    item->fieldPosition++;
                    while(item->fieldPosition < len && 
                          (item->field[item->fieldPosition] & 0xC0) == 0x80) {
                        item->fieldPosition++;
                    }
                }
            } else if(key == K_BACKSPACE) {
                if(item->fieldPosition > 0) {
                    int start = item->fieldPosition - 1;
                    int bytesToDelete;
                    while(start > 0 && (item->field[start] & 0xC0) == 0x80) {
                        start--;
                    }
                    bytesToDelete = item->fieldPosition - start;
                    memmove(item->field + start, item->field + item->fieldPosition, len - item->fieldPosition + 1);
                    item->fieldPosition = start;
                }
            } else if(key == K_HOME) {
                item->fieldPosition = 0;
            } else if(key == K_END) {
                item->fieldPosition = len;
            } else if(key == K_DEL) {
                Menu_DefaultKey(K_RIGHTARROW, qfalse, qfalse);
                Menu_DefaultKey(K_BACKSPACE, qfalse, qfalse);
            } else if(key == K_ENTER) {
                cvarSet(uis.items[uis.waitingKey].action, uis.items[uis.waitingKey].field);
                JS_MenuCallback(uis.items[uis.waitingKey].id);
                Menu_DefaultKey(K_ESCAPE, qfalse, qfalse);
            }
        }
    }

	switch(key) {
	case K_ESCAPE: UI_SetActiveMenu(UI_DISABLE); break;
    case K_F5: UI_HotReloadJS(); break;
	}

	item = Menu_CurrentItem();

	switch(key) {
	case K_MOUSE1: if(Menu_CursorOnItem(item->id)) UI_GeneralCallback(item, key); JS_MenuCallback(item->id); break;
	default: UI_GeneralCallback(item, key); JS_MenuCallback(item->id); break;
	}
	
	JS_MenuKey(key);
}

static qboolean UI_GenericItem(int type, int id, float x, float y, float w, float h, char *text, int style, float size, int colortext, int colorbg, int corner, int margin, char *action) {
    if(id >= MAX_DESKTOP_ITEMS) {
        print("^3Menu item limit exceeded");
        return qfalse;
    }
    uis.items[id].type = type;
    uis.items[id].id = id;
	uis.items[id].x = x;
	uis.items[id].y = y;
	uis.items[id].w = w;
	uis.items[id].h = h;
	StringCopy(uis.items[id].text, text, UI_STRINGLENGTH);
	uis.items[id].style = style;
	uis.items[id].size = size;
	uis.items[id].colortext = colortext;
	uis.items[id].colorbg = colorbg;
	uis.items[id].corner = corner;
	uis.items[id].margin = margin;
	StringCopy(uis.items[id].action, action, UI_ACTIONLENGTH);
	return qtrue;
}

int UI_CButton(int id, float x, float y, float w, float h, char *text, int style, float size, int colortext, int colorbg, int corner, int margin, char *action) {
    if(!UI_GenericItem(MTYPE_BUTTON, id, x, y, w, h, text, style, size, colortext, colorbg, corner, margin, action)) return -1;
    return id;
}

int UI_CCheckbox(int id, float x, float y, float w, float h, char *text, int style, float size, int colortext, int colorbg, int corner, int margin, char *action) {
    if(!UI_GenericItem(MTYPE_CHECKBOX, id, x, y, w, h, text, style, size, colortext, colorbg, corner, margin, action)) return -1;
	uis.items[id].value = cvarFloat(uis.items[id].action);
	return id;
}

int UI_CSlider(int id, float x, float y, float w, float h, char *text, int style, float size, int colortext, int colorbg, int corner, int margin, char *action, float min, float max, int mode) {
    if(!UI_GenericItem(MTYPE_SLIDER, id, x, y, w, h, text, style, size, colortext, colorbg, corner, margin, action)) return -1;
	uis.items[id].value = cvarFloat(uis.items[id].action);
	uis.items[id].min = min;
	uis.items[id].max = max;
	uis.items[id].mode = mode;
	return id;
}

int UI_CAction(int id, float x, float y, float w, float h, char *text, int style, float size, int colortext, int colorbg, int corner, int margin, char *action) {
    int i;
    if(!UI_GenericItem(MTYPE_ACTION, id, x, y, w, h, text, style, size, colortext, colorbg, corner, margin, action)) return -1;
	for(i = 0; i < MAX_KEYS; i++) {
	    if(!strcmp(action, cgui.binds[i])) trap_Key_KeynumToStringBuf(i, uis.items[id].bind, 256);
	}
	return id;
}

int UI_CSpin(int id, float x, float y, float w, float h, char *text, int style, float size, int colortext, int colorbg, int corner, int margin, char *action, int mode) {
    int i;
    if(!UI_GenericItem(MTYPE_SPIN, id, x, y, w, h, text, style, size, colortext, colorbg, corner, margin, action)) return -1;
    uis.items[id].mode = mode;
    if(mode == EMODE_NUMBER) {
        uis.items[id].value = cvarFloat(uis.items[id].action);
    } else if(mode == EMODE_STRING) {
        for(i = 0; i < uis.items[id].optionsCount; i++) {
            if(!strcmp(cvarString(uis.items[id].action), uis.items[id].options[i])) uis.items[id].value = i;
        }
    }
    return id;
}

int UI_CField(int id, float x, float y, float w, float h, char *text, int style, float size, int colortext, int colorbg, int corner, int margin, char *action) {
    if(!UI_GenericItem(MTYPE_FIELD, id, x, y, w, h, text, style, size, colortext, colorbg, corner, margin, action)) return -1;
    StringCopy(uis.items[id].field, cvarString(action), UI_FIELDLENGTH);
    uis.items[id].fieldPosition = strlen(cvarString(action));
    return id;
}

int UI_CList(int id, float x, float y, float w, float h, char *text, int style, float size, int colortext, int colorbg, int corner, int margin, char *action, int list, int drawCount) {
    if(!UI_GenericItem(MTYPE_LIST, id, x, y, w, h, text, style, size, colortext, colorbg, corner, margin, action)) return -1;
    uis.items[id].list = list;
    uis.items[id].value = 0;
    uis.items[id].drawCount = drawCount;
    return id;
}

void UI_FillListFiles(int list, const char *folder, const char *extension, const char *drawFolder, const char *drawExtension) {
    uis.listCount[list] = FS_List(folder, extension, uis.list[list], UI_LISTLENGTH);
    StringCopy(uis.drawFolder[list], drawFolder, UI_LISTFOLDERLENGTH);
    StringCopy(uis.drawExtension[list], drawExtension, UI_LISTEXTENSIONLENGTH);
}
